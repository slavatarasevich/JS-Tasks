'use strict';


fetch('https://api.openweathermap.org/data/2.5/forecast?lat=53.904541&lon=27.561523&appid=eae44c3ebf0781c0f22da631df12fb90&units=metric')
.then(response=>response.json())
.then(response => console.log(response));

//-------- getting the name -----------

fetch('http://api.openweathermap.org/geo/1.0/direct?q=Minsk&limit=5&appid=eae44c3ebf0781c0f22da631df12fb90')
.then(response=>response.json())
.then(response=> getName(response[0].local_names.cv))

function getName(name){
    document.querySelector('.city').innerHTML = name;
}

//-------- getting the current temperature -----------

fetch('https://api.openweathermap.org/data/2.5/forecast?lat=53.904541&lon=27.561523&appid=eae44c3ebf0781c0f22da631df12fb90&units=metric')
.then(response=>response.json())
.then(response=> getCurrentTemp(response.list[0].main.temp))

function getCurrentTemp(name){
    document.querySelector('.current-temp').innerHTML = Math.round(name) + '&#176';
}

//----------  getting description


fetch('https://api.openweathermap.org/data/2.5/forecast?lat=53.904541&lon=27.561523&appid=eae44c3ebf0781c0f22da631df12fb90&units=metric&lang=ru')
.then(response=>response.json())
.then(response=> getIcon(response.list[0].weather[0].description))

function getIcon(name){
    document.querySelector('.current-wording').innerHTML = name;
}

//----------  getting  feels like


fetch('https://api.openweathermap.org/data/2.5/forecast?lat=53.904541&lon=27.561523&appid=eae44c3ebf0781c0f22da631df12fb90&units=metric&lang=ru')
.then(response=>response.json())
.then(response=> getFeelsLike(response.list[0].main.feels_like))

function getFeelsLike(temp){
document.querySelector('.feels-like').innerHTML = 'Ощущается как ' + Math.round(temp) + '&#176';

}
   


// ---------  getting future forecast

// dates

fetch('https://api.openweathermap.org/data/2.5/forecast?lat=53.904541&lon=27.561523&appid=eae44c3ebf0781c0f22da631df12fb90&units=metric&lang=ru')
.then(response=>response.json())
.then(response=>renderDates(response.list))

function renderDates(arr){

    for (let i=0; i<arr.length; i+=8){

    fetch('https://api.openweathermap.org/data/2.5/forecast?lat=53.904541&lon=27.561523&appid=eae44c3ebf0781c0f22da631df12fb90&units=metric&lang=ru')
    .then(response=>response.json())
    .then(response=> getDate(response.list[i].dt_txt))

        function getDate(newDate){
            document.querySelector(`.d${i}`).innerHTML = newDate.slice(0,10);
        }
    }
}



//forecast for each day

fetch('https://api.openweathermap.org/data/2.5/forecast?lat=53.904541&lon=27.561523&appid=eae44c3ebf0781c0f22da631df12fb90&units=metric&lang=ru')
.then(response=>response.json())
.then(response=>renderFutureForecast(response.list))

function renderFutureForecast(arr){

    for (let i=0; i<arr.length; i+=8){

    fetch('https://api.openweathermap.org/data/2.5/forecast?lat=53.904541&lon=27.561523&appid=eae44c3ebf0781c0f22da631df12fb90&units=metric&lang=ru')
    .then(response=>response.json())
    .then(response=> getDailyForecast(response.list[i].main.temp))

        function getDailyForecast(newForecast){
            document.querySelector(`.df${i}`).innerHTML = Math.round(newForecast) + '&#176';
        }
    }
}



// let response = await fetch('https://api.openweathermap.org/data/2.5/forecast?lat=53.904541&lon=27.561523&appid=eae44c3ebf0781c0f22da631df12fb90&units=metric&lang=ru');
// let result = await response.json();
// console.log(result);













// let unix_timestamp = 1665549066
// // Create a new JavaScript Date object based on the timestamp
// // multiplied by 1000 so that the argument is in milliseconds, not seconds.
// var date = new Date(unix_timestamp * 1000);
// // Hours part from the timestamp
// var hours = date.getHours();
// // Minutes part from the timestamp
// var minutes = "0" + date.getMinutes();
// // Seconds part from the timestamp
// var seconds = "0" + date.getSeconds();

// // Will display time in 10:30:23 format
// var formattedTime = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);

// console.log(formattedTime);


// let wrapper = document.querySelector('.wrapper');

// let hrForecast = document.createElement('div');
// hrForecast.classList.add('hourly-forecast');
// hrForecast.innerText = 'Here I will add hourly forecast';
// hrForecast.style.width = '800px';
// hrForecast.style.height = '150px';
// hrForecast.style.marginTop = '15px';
// hrForecast.style.background = '#c5f6ef';
// document.body.append(hrForecast);
