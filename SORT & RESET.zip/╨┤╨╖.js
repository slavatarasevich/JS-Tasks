document.querySelector(".form").addEventListener("submit", onSubmitUser);
document.querySelector('input[name="search"]')?.addEventListener("keyup", onSearchUser);

// let removeBtn = document.getElementById('remove');
// removeBtn.addEventListener('click', removeUser);

const initialUsers = [
  {
    id: 1,
    firstName: "Ihar",
    lastName: "Slabykho",
  },
  {
    id: 2,
    firstName: "Ivan",
    lastName: "Slabykho",
  },
  {
    id: 3,
    firstName: "Oleg",
    lastName: "Ivanov",
  },
  {
    id: 4,
    firstName: "Alex",
    lastName: "Olegov",
  },
];


function sortInitialUsers(arg){
    let sortedArray = arg.sort((a, b)=>{
    const nameA = a.firstName.toLowerCase();  
    const nameB = b.firstName.toLowerCase();  
    if (nameA < nameB) {
      return -1;
    }
    if (nameA > nameB) {
      return 1;
    }
    return 0;

});
return sortedArray
};


function onSubmitUser(event) {
  event.preventDefault();
  let firstName = document.querySelector('input[name="userName"]').value;
  let lastName = document.querySelector('input[name="userLastname"]').value;
  addUsers(firstName, lastName);
  render();
}

function onSearchUser({ target: { value } }) {
  const result = initialUsers.filter((userData) => {
    if (userData.lastName.toLowerCase().includes(value.toLowerCase())) {
      return true;
    }

    if (userData.firstName.toLowerCase().includes(value.toLowerCase())) {
      return true;
    }

    return false;
  });

  render(result);
}

function addUsers(firstName, lastName) {
  initialUsers.push({
    id: Date.now(),
    firstName,
    lastName,
  });
}
// _______________________________________

// Delete users пока не реализована

// function removeUser(){
    

//     delete initialUsers[{id}];
//     render()

// }
//_________________________________________


function render(users = initialUsers) {
  const root = document.querySelector("#root");
  root.innerHTML = "";

  users.forEach((user) => {
    const li = document.createElement("li");
    li.dataset.id = user.id;

    const content = document.createElement("span");
    content.textContent = `${user.firstName} ${user.lastName}`;
    li.append(content);
    root.append(li);
  });
  sortInitialUsers(initialUsers)
  document.getElementById('form').reset()
}

render();

